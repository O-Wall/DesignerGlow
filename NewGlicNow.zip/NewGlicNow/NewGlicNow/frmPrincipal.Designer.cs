﻿namespace NewGlicNow
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlBordaForm = new System.Windows.Forms.Panel();
            this.picMinimize = new System.Windows.Forms.PictureBox();
            this.picClose = new System.Windows.Forms.PictureBox();
            this.lblDashboard = new System.Windows.Forms.Label();
            this.pnlBordaPerfil1 = new System.Windows.Forms.Panel();
            this.pnlBordaPerfil2 = new System.Windows.Forms.Panel();
            this.pnlBordaPerfil3 = new System.Windows.Forms.Panel();
            this.pnlBordaMenu2 = new System.Windows.Forms.Panel();
            this.pnlBordaMenu1 = new System.Windows.Forms.Panel();
            this.pnlBordaUcers = new System.Windows.Forms.Panel();
            this.pnlBordaMenu3 = new System.Windows.Forms.Panel();
            this.picPerfil = new System.Windows.Forms.PictureBox();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.btnConfiguracao = new System.Windows.Forms.Button();
            this.btnGlicemia = new System.Windows.Forms.Button();
            this.btnAgenda = new System.Windows.Forms.Button();
            this.pnlEnfeite = new System.Windows.Forms.Panel();
            this.picProfile = new System.Windows.Forms.PictureBox();
            this.lblNomePerfil = new System.Windows.Forms.Label();
            this.pnlBordaPerfil4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlBordaForm.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPerfil)).BeginInit();
            this.pnlMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picProfile)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlBordaForm
            // 
            this.pnlBordaForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.pnlBordaForm.Controls.Add(this.picMinimize);
            this.pnlBordaForm.Controls.Add(this.picClose);
            this.pnlBordaForm.Controls.Add(this.lblDashboard);
            this.pnlBordaForm.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBordaForm.Location = new System.Drawing.Point(0, 0);
            this.pnlBordaForm.Name = "pnlBordaForm";
            this.pnlBordaForm.Size = new System.Drawing.Size(954, 36);
            this.pnlBordaForm.TabIndex = 119;
            // 
            // picMinimize
            // 
            this.picMinimize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picMinimize.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.picMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picMinimize.Location = new System.Drawing.Point(894, 5);
            this.picMinimize.Name = "picMinimize";
            this.picMinimize.Size = new System.Drawing.Size(24, 24);
            this.picMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picMinimize.TabIndex = 45;
            this.picMinimize.TabStop = false;
            this.picMinimize.Click += new System.EventHandler(this.picMinimize_Click);
            // 
            // picClose
            // 
            this.picClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picClose.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.picClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picClose.Location = new System.Drawing.Point(924, 5);
            this.picClose.Name = "picClose";
            this.picClose.Size = new System.Drawing.Size(24, 24);
            this.picClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picClose.TabIndex = 44;
            this.picClose.TabStop = false;
            this.picClose.Click += new System.EventHandler(this.picClose_Click);
            // 
            // lblDashboard
            // 
            this.lblDashboard.AutoSize = true;
            this.lblDashboard.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.lblDashboard.ForeColor = System.Drawing.Color.White;
            this.lblDashboard.Location = new System.Drawing.Point(14, 7);
            this.lblDashboard.Name = "lblDashboard";
            this.lblDashboard.Size = new System.Drawing.Size(72, 21);
            this.lblDashboard.TabIndex = 26;
            this.lblDashboard.Text = "Principal";
            // 
            // pnlBordaPerfil1
            // 
            this.pnlBordaPerfil1.BackColor = System.Drawing.Color.Black;
            this.pnlBordaPerfil1.Location = new System.Drawing.Point(58, 57);
            this.pnlBordaPerfil1.Name = "pnlBordaPerfil1";
            this.pnlBordaPerfil1.Size = new System.Drawing.Size(2, 66);
            this.pnlBordaPerfil1.TabIndex = 112;
            // 
            // pnlBordaPerfil2
            // 
            this.pnlBordaPerfil2.BackColor = System.Drawing.Color.Black;
            this.pnlBordaPerfil2.Location = new System.Drawing.Point(122, 57);
            this.pnlBordaPerfil2.Name = "pnlBordaPerfil2";
            this.pnlBordaPerfil2.Size = new System.Drawing.Size(2, 66);
            this.pnlBordaPerfil2.TabIndex = 111;
            // 
            // pnlBordaPerfil3
            // 
            this.pnlBordaPerfil3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlBordaPerfil3.BackColor = System.Drawing.Color.Black;
            this.pnlBordaPerfil3.Location = new System.Drawing.Point(60, 57);
            this.pnlBordaPerfil3.Name = "pnlBordaPerfil3";
            this.pnlBordaPerfil3.Size = new System.Drawing.Size(63, 2);
            this.pnlBordaPerfil3.TabIndex = 118;
            // 
            // pnlBordaMenu2
            // 
            this.pnlBordaMenu2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlBordaMenu2.BackColor = System.Drawing.Color.Black;
            this.pnlBordaMenu2.Location = new System.Drawing.Point(123, 90);
            this.pnlBordaMenu2.Name = "pnlBordaMenu2";
            this.pnlBordaMenu2.Size = new System.Drawing.Size(62, 2);
            this.pnlBordaMenu2.TabIndex = 117;
            // 
            // pnlBordaMenu1
            // 
            this.pnlBordaMenu1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlBordaMenu1.BackColor = System.Drawing.Color.Black;
            this.pnlBordaMenu1.Location = new System.Drawing.Point(-3, 90);
            this.pnlBordaMenu1.Name = "pnlBordaMenu1";
            this.pnlBordaMenu1.Size = new System.Drawing.Size(63, 2);
            this.pnlBordaMenu1.TabIndex = 116;
            // 
            // pnlBordaUcers
            // 
            this.pnlBordaUcers.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlBordaUcers.BackColor = System.Drawing.Color.OrangeRed;
            this.pnlBordaUcers.Location = new System.Drawing.Point(185, 106);
            this.pnlBordaUcers.Name = "pnlBordaUcers";
            this.pnlBordaUcers.Size = new System.Drawing.Size(772, 2);
            this.pnlBordaUcers.TabIndex = 115;
            // 
            // pnlBordaMenu3
            // 
            this.pnlBordaMenu3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlBordaMenu3.BackColor = System.Drawing.Color.Black;
            this.pnlBordaMenu3.Location = new System.Drawing.Point(183, 92);
            this.pnlBordaMenu3.Name = "pnlBordaMenu3";
            this.pnlBordaMenu3.Size = new System.Drawing.Size(2, 503);
            this.pnlBordaMenu3.TabIndex = 114;
            // 
            // picPerfil
            // 
            this.picPerfil.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.picPerfil.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.picPerfil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picPerfil.Location = new System.Drawing.Point(59, 57);
            this.picPerfil.Name = "picPerfil";
            this.picPerfil.Size = new System.Drawing.Size(64, 64);
            this.picPerfil.TabIndex = 110;
            this.picPerfil.TabStop = false;
            // 
            // pnlMenu
            // 
            this.pnlMenu.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(137)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.pnlMenu.Controls.Add(this.btnConfiguracao);
            this.pnlMenu.Controls.Add(this.btnGlicemia);
            this.pnlMenu.Controls.Add(this.btnAgenda);
            this.pnlMenu.Controls.Add(this.pnlEnfeite);
            this.pnlMenu.Controls.Add(this.picProfile);
            this.pnlMenu.Controls.Add(this.lblNomePerfil);
            this.pnlMenu.Controls.Add(this.pnlBordaPerfil4);
            this.pnlMenu.Location = new System.Drawing.Point(-3, 92);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.pnlMenu.Size = new System.Drawing.Size(186, 504);
            this.pnlMenu.TabIndex = 113;
            // 
            // btnConfiguracao
            // 
            this.btnConfiguracao.FlatAppearance.BorderSize = 0;
            this.btnConfiguracao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfiguracao.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfiguracao.ForeColor = System.Drawing.Color.White;
            this.btnConfiguracao.Location = new System.Drawing.Point(13, 208);
            this.btnConfiguracao.Name = "btnConfiguracao";
            this.btnConfiguracao.Size = new System.Drawing.Size(173, 45);
            this.btnConfiguracao.TabIndex = 112;
            this.btnConfiguracao.Text = "Configurações";
            this.btnConfiguracao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConfiguracao.UseVisualStyleBackColor = true;
            this.btnConfiguracao.Click += new System.EventHandler(this.btnConfiguracao_Click);
            // 
            // btnGlicemia
            // 
            this.btnGlicemia.FlatAppearance.BorderSize = 0;
            this.btnGlicemia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGlicemia.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGlicemia.ForeColor = System.Drawing.Color.White;
            this.btnGlicemia.Location = new System.Drawing.Point(13, 141);
            this.btnGlicemia.Name = "btnGlicemia";
            this.btnGlicemia.Size = new System.Drawing.Size(173, 45);
            this.btnGlicemia.TabIndex = 111;
            this.btnGlicemia.Text = "Mapa de Glicemia";
            this.btnGlicemia.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGlicemia.UseVisualStyleBackColor = true;
            this.btnGlicemia.Click += new System.EventHandler(this.btnGlicemia_Click);
            // 
            // btnAgenda
            // 
            this.btnAgenda.FlatAppearance.BorderSize = 0;
            this.btnAgenda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAgenda.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAgenda.ForeColor = System.Drawing.Color.White;
            this.btnAgenda.Location = new System.Drawing.Point(14, 74);
            this.btnAgenda.Name = "btnAgenda";
            this.btnAgenda.Size = new System.Drawing.Size(173, 45);
            this.btnAgenda.TabIndex = 110;
            this.btnAgenda.Text = "Agenda";
            this.btnAgenda.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgenda.UseVisualStyleBackColor = true;
            this.btnAgenda.Click += new System.EventHandler(this.btnAgenda_Click);
            // 
            // pnlEnfeite
            // 
            this.pnlEnfeite.BackColor = System.Drawing.Color.OrangeRed;
            this.pnlEnfeite.Location = new System.Drawing.Point(2, 74);
            this.pnlEnfeite.Name = "pnlEnfeite";
            this.pnlEnfeite.Size = new System.Drawing.Size(8, 45);
            this.pnlEnfeite.TabIndex = 20;
            // 
            // picProfile
            // 
            this.picProfile.Location = new System.Drawing.Point(4, 295);
            this.picProfile.Name = "picProfile";
            this.picProfile.Size = new System.Drawing.Size(182, 202);
            this.picProfile.TabIndex = 37;
            this.picProfile.TabStop = false;
            // 
            // lblNomePerfil
            // 
            this.lblNomePerfil.AutoSize = true;
            this.lblNomePerfil.BackColor = System.Drawing.Color.Transparent;
            this.lblNomePerfil.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomePerfil.Location = new System.Drawing.Point(40, 34);
            this.lblNomePerfil.Name = "lblNomePerfil";
            this.lblNomePerfil.Size = new System.Drawing.Size(110, 17);
            this.lblNomePerfil.TabIndex = 35;
            this.lblNomePerfil.Text = "Nome do Sujeito";
            // 
            // pnlBordaPerfil4
            // 
            this.pnlBordaPerfil4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pnlBordaPerfil4.BackColor = System.Drawing.Color.Black;
            this.pnlBordaPerfil4.Location = new System.Drawing.Point(63, 29);
            this.pnlBordaPerfil4.Name = "pnlBordaPerfil4";
            this.pnlBordaPerfil4.Size = new System.Drawing.Size(64, 2);
            this.pnlBordaPerfil4.TabIndex = 34;
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Location = new System.Drawing.Point(183, 107);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(771, 3);
            this.panel1.TabIndex = 115;
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(954, 594);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlBordaForm);
            this.Controls.Add(this.pnlBordaPerfil1);
            this.Controls.Add(this.pnlBordaPerfil2);
            this.Controls.Add(this.pnlBordaPerfil3);
            this.Controls.Add(this.pnlBordaMenu2);
            this.Controls.Add(this.pnlBordaMenu1);
            this.Controls.Add(this.pnlBordaMenu3);
            this.Controls.Add(this.picPerfil);
            this.Controls.Add(this.pnlMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPrincipal";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmPrincipal_FormClosing);
            this.Load += new System.EventHandler(this.frmPrincipal_Load);
            this.pnlBordaForm.ResumeLayout(false);
            this.pnlBordaForm.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picMinimize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPerfil)).EndInit();
            this.pnlMenu.ResumeLayout(false);
            this.pnlMenu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picProfile)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlBordaForm;
        private System.Windows.Forms.Label lblDashboard;
        private System.Windows.Forms.Panel pnlBordaPerfil1;
        private System.Windows.Forms.Panel pnlBordaPerfil2;
        private System.Windows.Forms.Panel pnlBordaPerfil3;
        private System.Windows.Forms.Panel pnlBordaMenu2;
        private System.Windows.Forms.Panel pnlBordaMenu1;
        private System.Windows.Forms.Panel pnlBordaUcers;
        private System.Windows.Forms.Panel pnlBordaMenu3;
        private System.Windows.Forms.PictureBox picPerfil;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Button btnConfiguracao;
        private System.Windows.Forms.Button btnGlicemia;
        private System.Windows.Forms.Button btnAgenda;
        private System.Windows.Forms.Panel pnlEnfeite;
        private System.Windows.Forms.PictureBox picProfile;
        private System.Windows.Forms.Label lblNomePerfil;
        private System.Windows.Forms.Panel pnlBordaPerfil4;
        private System.Windows.Forms.PictureBox picClose;
        private System.Windows.Forms.PictureBox picMinimize;
        private System.Windows.Forms.Panel panel1;
    }
}